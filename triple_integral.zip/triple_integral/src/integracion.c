#include <stdlib.h>
#include <time.h>
#include "../include/integracion.h"

double integral_triple_riemann(
    FuncionDensidad f,
    ParametrosDensidad* params,
    LimitesIntegracion limites,
    int nx, int ny, int nz
) {
    double dx = (limites.xmax - limites.xmin) / nx;
    double dy = (limites.ymax - limites.ymin) / ny;
    double dz = (limites.zmax - limites.zmin) / nz;
    
    double dV = dx * dy * dz;
    double suma = 0.0;
    
    for (int i = 0; i < nx; i++) {
        double x = limites.xmin + (i + 0.5) * dx;
        for (int j = 0; j < ny; j++) {
            double y = limites.ymin + (j + 0.5) * dy;
            for (int k = 0; k < nz; k++) {
                double z = limites.zmin + (k + 0.5) * dz;
                suma += f(x, y, z, params);
            }
        }
    }
    
    return suma * dV;
}

double integral_triple_monte_carlo(
    FuncionDensidad f,
    ParametrosDensidad* params,
    LimitesIntegracion limites,
    int n_muestras
) {
    double volumen = (limites.xmax - limites.xmin) * 
                     (limites.ymax - limites.ymin) * 
                     (limites.zmax - limites.zmin);
    
    double suma = 0.0;
    
    for (int i = 0; i < n_muestras; i++) {
        double x = limites.xmin + ((double)rand() / RAND_MAX) * (limites.xmax - limites.xmin);
        double y = limites.ymin + ((double)rand() / RAND_MAX) * (limites.ymax - limites.ymin);
        double z = limites.zmin + ((double)rand() / RAND_MAX) * (limites.zmax - limites.zmin);
        
        suma += f(x, y, z, params);
    }
    
    return volumen * (suma / n_muestras);
}

ResultadoCentroMasa calcular_centro_masa_riemann(
    FuncionDensidad densidad,
    ParametrosDensidad* params,
    LimitesIntegracion limites,
    int nx, int ny, int nz
) {
    ResultadoCentroMasa resultado;
    
    double dx = (limites.xmax - limites.xmin) / nx;
    double dy = (limites.ymax - limites.ymin) / ny;
    double dz = (limites.zmax - limites.zmin) / nz;
    
    double dV = dx * dy * dz;
    
    double masa = 0.0;
    double momento_x = 0.0;
    double momento_y = 0.0;
    double momento_z = 0.0;
    
    for (int i = 0; i < nx; i++) {
        double x = limites.xmin + (i + 0.5) * dx;
        for (int j = 0; j < ny; j++) {
            double y = limites.ymin + (j + 0.5) * dy;
            for (int k = 0; k < nz; k++) {
                double z = limites.zmin + (k + 0.5) * dz;
                double rho = densidad(x, y, z, params);
                
                masa += rho;
                momento_x += x * rho;
                momento_y += y * rho;
                momento_z += z * rho;
            }
        }
    }
    
    masa *= dV;
    momento_x *= dV;
    momento_y *= dV;
    momento_z *= dV;
    
    resultado.masa = masa;
    resultado.x_bar = momento_x / masa;
    resultado.y_bar = momento_y / masa;
    resultado.z_bar = momento_z / masa;
    
    return resultado;
}

ResultadoCentroMasa calcular_centro_masa_monte_carlo(
    FuncionDensidad densidad,
    ParametrosDensidad* params,
    LimitesIntegracion limites,
    int n_muestras
) {
    ResultadoCentroMasa resultado;
    
    double volumen = (limites.xmax - limites.xmin) * 
                     (limites.ymax - limites.ymin) * 
                     (limites.zmax - limites.zmin);
    
    double suma_rho = 0.0;
    double suma_x_rho = 0.0;
    double suma_y_rho = 0.0;
    double suma_z_rho = 0.0;
    
    for (int i = 0; i < n_muestras; i++) {
        double x = limites.xmin + ((double)rand() / RAND_MAX) * (limites.xmax - limites.xmin);
        double y = limites.ymin + ((double)rand() / RAND_MAX) * (limites.ymax - limites.ymin);
        double z = limites.zmin + ((double)rand() / RAND_MAX) * (limites.zmax - limites.zmin);
        
        double rho = densidad(x, y, z, params);
        
        suma_rho += rho;
        suma_x_rho += x * rho;
        suma_y_rho += y * rho;
        suma_z_rho += z * rho;
    }
    
    double masa = volumen * (suma_rho / n_muestras);
    double momento_x = volumen * (suma_x_rho / n_muestras);
    double momento_y = volumen * (suma_y_rho / n_muestras);
    double momento_z = volumen * (suma_z_rho / n_muestras);
    
    resultado.masa = masa;
    resultado.x_bar = momento_x / masa;
    resultado.y_bar = momento_y / masa;
    resultado.z_bar = momento_z / masa;
    
    return resultado;
}
//Juan Manuel Candela