#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "../include/integracion.h"
#include "../include/densidades.h"

void imprimir_menu() {
    printf("\nCalculadora de Masa y Centro de Masa\n");
}

void imprimir_menu_densidades() {
    printf("\nSeleccione el tipo de densidad:\n");
    printf("1. Densidad constante: rho(x,y,z) = 1\n");
    printf("Representa un material homogéneo de densidad uniforme.\n");
    printf("2.Densidad lineal: rho(x,y,z) = ax + by + cz\n");
    printf("Representa un material cuya densidad varía linealmente en el espacio.\n");
    printf("3.Densidad gaussiana: rho(x,y,z) = exp(-(x² + y² + z²))\n");
    printf("Representa una distribución con maximo en el origen que decae exponencialmente.\n");
    printf("Opción: ");
}

void imprimir_menu_metodos() {
    printf("\nSeleccione el mtodo de integracion:\n");
    printf("1. Sumas de Riemann\n");
    printf("2. Monte Carlo\n");
    printf("Opcion: ");
}

int main() {
    imprimir_menu();
    
    LimitesIntegracion limites;
    printf("Ingrese los limites de integracion:\n");
    printf("xmin: "); scanf("%lf", &limites.xmin);
    printf("xmax: "); scanf("%lf", &limites.xmax);
    printf("ymin: "); scanf("%lf", &limites.ymin);
    printf("ymax: "); scanf("%lf", &limites.ymax);
    printf("zmin: "); scanf("%lf", &limites.zmin);
    printf("zmax: "); scanf("%lf", &limites.zmax);
    
    imprimir_menu_densidades();
    int opcion_densidad;
    scanf("%d", &opcion_densidad);
    
    FuncionDensidad densidad;
    char nombre_densidad[50];
    ParametrosDensidad params = {0, 0, 0};
    
    switch(opcion_densidad) {
        case 1:
            densidad = densidad_constante;
            strcpy(nombre_densidad, "Constante");
            break;
        case 2:
            densidad = densidad_lineal;
            strcpy(nombre_densidad, "Lineal");
            printf("Ingrese los parametros a, b, c:\n");
            printf("a: "); scanf("%lf", &params.a);
            printf("b: "); scanf("%lf", &params.b);
            printf("c: "); scanf("%lf", &params.c);
            break;
        case 3:
            densidad = densidad_gaussiana;
            strcpy(nombre_densidad, "Gaussiana");
            break;
        default:
            printf("Opcion inválida. Usando densidad constante.\n");
            densidad = densidad_constante;
            strcpy(nombre_densidad, "Constante");
    }
    
    imprimir_menu_metodos();
    int opcion_metodo;
    scanf("%d", &opcion_metodo);
    
    ResultadoCentroMasa resultado;
    char nombre_metodo[50];
    int nx = 0, ny = 0, nz = 0;
    
    clock_t inicio = clock();
    
    if (opcion_metodo == 1) {
        strcpy(nombre_metodo, "Riemann");
        printf("\nIngrese el numero de subdivisiones:\n");
        printf("Nx: "); scanf("%d", &nx);
        printf("Ny: "); scanf("%d", &ny);
        printf("Nz: "); scanf("%d", &nz);
        
        resultado = calcular_centro_masa_riemann(densidad, &params, limites, nx, ny, nz);
    } else {
        strcpy(nombre_metodo, "MonteCarlo");
        int n_muestras;
        printf("\nIngrese el numero de muestras: ");
        scanf("%d", &n_muestras);
        
        srand(time(NULL));
        
        resultado = calcular_centro_masa_monte_carlo(densidad, &params, limites, n_muestras);
        
        nx = n_muestras;
        ny = 0;
        nz = 0;
    }
    
    clock_t fin = clock();
    double tiempo = (double)(fin - inicio) / CLOCKS_PER_SEC;
    
    printf("\n=== RESULTADOS ===\n");
    printf("Metodo: %s\n", nombre_metodo);
    printf("Densidad: %s\n", nombre_densidad);
    printf("Masa total (M): %.6f\n", resultado.masa);
    printf("Centro de masa:\n");
    printf("  x = %.6f\n", resultado.x_bar);
    printf("  y = %.6f\n", resultado.y_bar);
    printf("  z = %.6f\n", resultado.z_bar);
    printf("Tiempo de ejecución: segundos\n", tiempo);
    
    FILE* archivo = fopen("resultados.csv", "a");
    if (archivo == NULL) {
        archivo = fopen("resultados.csv", "w");
        fprintf(archivo, "Metodo,Densidad,Nx,Ny,Nz,M,x_bar,y_bar,z_bar,Tiempo\n");
    }
    
    fprintf(archivo, "%s,%s,%d,%d,%d,%.6f,%.6f,%.6f,%.6f,%.6f\n",
            nombre_metodo, nombre_densidad, nx, ny, nz,
            resultado.masa, resultado.x_bar, resultado.y_bar, resultado.z_bar, tiempo);
    
    fclose(archivo);
    return 0;
}
//Juan Manuel Candela