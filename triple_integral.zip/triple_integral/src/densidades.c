#include <math.h>
#include "../include/densidades.h"

double densidad_constante(double x, double y, double z, ParametrosDensidad* params) {
    return 1.0;
}

double densidad_lineal(double x, double y, double z, ParametrosDensidad* params) {
    return params->a * x + params->b * y + params->c * z;
}

double densidad_gaussiana(double x, double y, double z, ParametrosDensidad* params) {
    return exp(-(x*x + y*y + z*z));
}
//Juan Manuel Candela