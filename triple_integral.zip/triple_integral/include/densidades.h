#ifndef DENSIDADES_H
#define DENSIDADES_H

typedef struct {
    double a;
    double b;
    double c;
} ParametrosDensidad;

double densidad_constante(double x, double y, double z, ParametrosDensidad* params);

double densidad_lineal(double x, double y, double z, ParametrosDensidad* params);

double densidad_gaussiana(double x, double y, double z, ParametrosDensidad* params);
//Juan Manuel Candela
#endif