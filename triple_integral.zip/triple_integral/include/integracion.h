#ifndef INTEGRACION_H
#define INTEGRACION_H

#include "densidades.h"

typedef double (*FuncionDensidad)(double, double, double, ParametrosDensidad*);

typedef struct {
    double xmin, xmax;
    double ymin, ymax;
    double zmin, zmax;
} LimitesIntegracion;

typedef struct {
    double masa;
    double x_bar;
    double y_bar;
    double z_bar;
} ResultadoCentroMasa;

double integral_triple_riemann(
    FuncionDensidad f,
    ParametrosDensidad* params,
    LimitesIntegracion limites,
    int nx, int ny, int nz
);

double integral_triple_monte_carlo(
    FuncionDensidad f,
    ParametrosDensidad* params,
    LimitesIntegracion limites,
    int n_muestras
);

ResultadoCentroMasa calcular_centro_masa_riemann(
    FuncionDensidad densidad,
    ParametrosDensidad* params,
    LimitesIntegracion limites,
    int nx, int ny, int nz
);

ResultadoCentroMasa calcular_centro_masa_monte_carlo(
    FuncionDensidad densidad,
    ParametrosDensidad* params,
    LimitesIntegracion limites,
    int n_muestras
);
//Juan Manuel Candela
#endif